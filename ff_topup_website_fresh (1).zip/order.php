
<?php
$ffid = $_POST['ffid'];
$diamond = $_POST['diamond'];
$payment = $_POST['payment'];
$number = $_POST['number'];

$file = fopen("orders.txt", "a");
fwrite($file, "ID: $ffid | Diamond: $diamond | Payment: $payment | Number: $number\n");
fclose($file);

echo "✅ আপনার অর্ডার গ্রহণ করা হয়েছে। ধন্যবাদ!";
?>
