FF TopUp Admin Panel
--------------------

Files included:
- admin.php : Admin panel script
- orders.csv : Orders storage file (initially empty)

How to use:
1. Upload files to your PHP hosting server.
2. Access admin.php in browser.
3. Login with username: admin, password: admin123
4. Confirm orders manually.
