<?php
session_start();

// Simple admin login: username=admin, password=admin123
if (isset($_POST['username']) && isset($_POST['password'])) {
    if ($_POST['username'] == 'admin' && $_POST['password'] == 'admin123') {
        $_SESSION['admin_logged_in'] = true;
        header('Location: admin.php');
        exit;
    } else {
        $error = "Invalid username or password";
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

if (!isset($_SESSION['admin_logged_in'])) {
?>
    <h2>Admin Login</h2>
    <?php if (isset($error)) echo '<p style="color:red;">'.$error.'</p>'; ?>
    <form method="post" action="admin.php">
        Username: <input type="text" name="username" required><br><br>
        Password: <input type="password" name="password" required><br><br>
        <button type="submit">Login</button>
    </form>
<?php
    exit;
}

// Confirm order if requested
if (isset($_GET['confirm'])) {
    $order_id = intval($_GET['confirm']);
    $orders = file('orders.csv');
    if (isset($orders[$order_id])) {
        $order = explode(',', trim($orders[$order_id]));
        $order[5] = 'confirmed'; // update status
        $orders[$order_id] = implode(',', $order) . "\n";
        file_put_contents('orders.csv', implode('', $orders));
    }
    header('Location: admin.php');
    exit;
}

// Display orders
$orders = file_exists('orders.csv') ? file('orders.csv') : [];
?>

<h2>Admin Panel</h2>
<p><a href="admin.php?logout=1">Logout</a></p>
<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>FF ID</th>
        <th>Package</th>
        <th>Diamond Amount</th>
        <th>Payment Method</th>
        <th>Transaction ID</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    <?php foreach ($orders as $index => $line): 
        $order = explode(',', trim($line)); ?>
        <tr>
            <td><?= $index ?></td>
            <td><?= htmlspecialchars($order[0]) ?></td>
            <td><?= htmlspecialchars($order[1]) ?></td>
            <td><?= htmlspecialchars($order[2]) ?></td>
            <td><?= htmlspecialchars($order[3]) ?></td>
            <td><?= htmlspecialchars($order[4]) ?></td>
            <td><?= htmlspecialchars($order[5]) ?></td>
            <td>
                <?php if ($order[5] == 'pending'): ?>
                    <a href="admin.php?confirm=<?= $index ?>">Confirm</a>
                <?php else: ?>
                    Confirmed
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
