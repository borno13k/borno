FF TopUp Basic App
-------------------

How to use:
1. Upload all files to your PHP hosting server.
2. Access index.php to place an order.
3. Payment is manual: users pay to 01742-555689 via Bkash or Nagad.
4. Users submit transaction ID on order form.
5. Admin logs in via admin.php with username=admin and password=admin123.
6. Admin confirms orders manually after verifying payment.
7. Orders stored in orders.csv file.

Note: This is a basic demo app without a database or real payment gateway integration.
Use this as a starting point and customize as needed.
