<?php
// Simple order form for FF TopUp
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FF TopUp Order</title>
</head>
<body>
    <h1>FF TopUp Order</h1>
    <form action="submit_order.php" method="post">
        <label>Free Fire ID:</label><br>
        <input type="text" name="ff_id" required><br><br>

        <label>Select Package:</label><br>
        <select name="package_type">
            <option value="diamond">Diamond (1 tk each)</option>
            <option value="weekly">Weekly Package (1 tk)</option>
            <option value="monthly">Monthly Package (1 tk)</option>
        </select><br><br>

        <label>Diamond Amount (if diamond package):</label><br>
        <input type="number" name="diamond_amount" min="1" value="1"><br><br>

        <label>Payment Method:</label><br>
        <input type="radio" name="payment_method" value="bkash" checked>Bkash<br>
        <input type="radio" name="payment_method" value="nagad">Nagad<br><br>

        <label>Send Payment to: <b>01742-555689</b></label><br><br>

        <label>Transaction ID (after payment):</label><br>
        <input type="text" name="transaction_id" required><br><br>

        <button type="submit">Submit Order</button>
    </form>
</body>
</html>
