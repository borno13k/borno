<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ff_id = $_POST['ff_id'];
    $package_type = $_POST['package_type'];
    $diamond_amount = intval($_POST['diamond_amount']);
    $payment_method = $_POST['payment_method'];
    $transaction_id = $_POST['transaction_id'];

    // Simple storage as CSV for demo (no DB)
    $order_line = "$ff_id,$package_type,$diamond_amount,$payment_method,$transaction_id,pending\n";
    file_put_contents('orders.csv', $order_line, FILE_APPEND);

    echo "<h2>Order submitted successfully!</h2>";
    echo "<p>Wait for admin confirmation.</p>";
    echo '<a href="index.php">Back to order page</a>';
} else {
    header('Location: index.php');
    exit;
}
?>